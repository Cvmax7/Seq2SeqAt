# HMER Tool V2.0

This code is writting by **Hongyu Wang** and **Wenliang Liu** in BeiHang university.  

## Requirements

	TKinter (This is Python GUI, and it is already in python3.6.)

## Using  
    python finalTK.py  

## Notice  
1、This is a beta version. So, many places are imperfect.  
2、You will see different interfaces in different operating systems(Linux、MacOS、Windows). Therefore, some BUGs may be happened.  
3、As PIL doesn't support enough LaTex symbols, some LaTex symbols can not show up.  
4、If you have some problems, please contact to me.  

## Experiment

![avatar](http://m.qpic.cn/psb?/V13MmUWH1KBoey/cSxJwct3igMrt7JpIN0u3utDmf3n4JMRnrD7p56h.oU!/b/dIQAAAAAAAAA&bo=CARtAggEbQIDCSw!&rf=viewer_4)

![avatar](http://m.qpic.cn/psb?/V13MmUWH1KBoey/043lwUtm5FugVU54Fz9R0MA1hTTX8Yx6PUtLBw7KGkI!/b/dMAAAAAAAAAA&bo=RQS1AkUEtQIDGTw!&rf=viewer_4)

![avatar](http://m.qpic.cn/psb?/V13MmUWH1KBoey/NBKFZoaWCCAuNeSn.JwL4MjlP2LuNBB*XuUTZkYOyRA!/b/dEYBAAAAAAAA&bo=RQS1AkUEtQIDKQw!&rf=viewer_4)



